package com.example.responsi2_124210081

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
